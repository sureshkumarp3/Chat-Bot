package com.example.aimlchatbot.AimlChatbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AimlChatbotApplicationTests {

	@Test
	void contextLoads() {
	}

}
