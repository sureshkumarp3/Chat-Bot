package com.example.aimlchatbot.AimlChatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AimlChatbotApplication {

	public static void main(String[] args) {
		SpringApplication.run(AimlChatbotApplication.class, args);
	}

}
