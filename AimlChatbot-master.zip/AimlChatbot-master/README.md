# AimlChatbot
# A NLP chatbot in Java, spring-boot, web socket and AIML

# Implementation
1. Add ab.jar in project (available with this repo)
2. Update path of ab.jar in pom.xml
3. Clean and Build pom.xml file
4. Update chat script as per your need on src\main\resources\bots\super\aimlif and aiml folder (it is good to write your own dataset based on this format)
5. update js and css and html as per your need... you can try it on android also..this is just a java application with spring..insetad of Maven update your code as Gradle.

# Reference for WebSocket :- https://spring.io/guides/gs/messaging-stomp-websocket/#scratch
# Reference for AIML :- https://www.tutorialspoint.com/aiml/index.htm
# This alice bot aiml dataset and code i had found long year ago..so do not have remember the URL, But you can update it by yourself....or Google as AliceBot or how to use Ab.Jar

